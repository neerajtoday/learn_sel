#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      bunti
#
# Created:     05/11/2018
# Copyright:   (c) bunti 2018
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import os

from robot.libraries import BuiltIn
from selenium import webdriver
from robot.libraries.BuiltIn import BuiltIn
from selenium.webdriver.common.keys import Keys

def Open_Test():
   # get the path of ChromeDriverServer
   dir = os.path.dirname(__file__)
   #chrome_driver_path = "C:\bin\chromedriver.exe"

   # create a new Chrome session
   driver = webdriver.Chrome()
   driver.implicitly_wait(10)
   driver.maximize_window()

   # Navigate to the application home page
   driver.get("http://www.google.com")

   # get the search textbox
   search_field = driver.find_element_by_name("q")

   # enter search keyword and submit
   search_field.send_keys("data")
   search_field.submit()

   # get the list of elements which are displayed after the search
   # currently on result page using find_elements_by_class_name method
   lists= driver.find_elements_by_class_name("g")

   # get the number of elements found
   print ("Found " + str(len(lists)) + " searches:")
   BuiltIn().log_to_console("Found " + str(len(lists)) + " searches:")

   # iterate through each element and print the text that is
   # name of the search

   i=0
   for listitem in lists:
      print (listitem.get_attribute("innerHTML"))
      BuiltIn().log_to_console(listitem.get_attribute("innerHTML"))
      i=i+1
      if(i>10):
         break

   # close the browser window
   driver.quit()


#Open_Test()