import pandas as pd
import pytz
from pytz import timezone
import datetime as dt
from pytz import all_timezones

xls1 = pd.ExcelFile(r'C:\Users\Neeraj\testdemo.xlsx')
df1 = pd.read_excel(xls1, 'demo1', index_col=None, na_values=['NA',''])
df2 = pd.read_excel(xls1, 'demo2', index_col=None, na_values=['NA',''])
print(df1)
print('--'*4)
print(df2)
print('--'*4)
print(df1.columns)
print('--'*4)
print(df2.columns)
print('--'*4)
print(df1.shape[0])
print(df1.shape[1])
print('--'*4)
print(df2.shape[0])
print(df2.shape[1])
print('--'*2)
# print(df1[['col1', 'col2']])
print(df1.iloc[0,0])
print(df1.iloc[0,1])
print('--'*2)
print(df1.loc[0,'col1'])
print(df1.loc[0,'col5'])
"""
print('--'*9)
for i in range(len(df1)) :
  print(df1.iloc[i])
for i in range(len(df1)) :
  print(df1.loc[i, "col3"], df1.loc[i, "col2"])
print('--' * 9)
for index, row in df2.iterrows():
  print(index, row['col11'], row['col21'])
"""
print('--' * 2)
print(df1.loc[df1['col1']== 'r112'])
print('--' * 4)
print(df1.sort_values(['col1', 'col3'], ascending= False))
print(df1.sort_values(['col1', 'col3'], ascending= [1,0]))# col1 asc and col3 is des
print('--' * 4)
cols = list(df1.columns)
print(cols)
print('--' * 4)
df1['new'] = 'exe'
df1['new1'] = df1['new'] + df1['col1']
#df1['time'] = dt.datetime.strftime(dt.datetime.now(),'%u_%U_%w_%W_%Z%z_%H_%M_%S')

utc = pytz.utc
eastern = timezone('US/Eastern')
amsterdam = timezone('Europe/Brussels')
india =  timezone('Asia/Calcutta')
print(dt.datetime.utcnow())
print(dt.datetime.now())
#utc_dt = datetime(2002, 10, 27, 6, 0, 0, tzinfo=utc)
fmt = '%Y-%m-%d %H:%M:%S %Z'
print(utc.localize(dt.datetime.utcnow()).astimezone(eastern).strftime(fmt))
print(utc.localize(dt.datetime.utcnow()).astimezone(amsterdam).strftime(fmt))
print(utc.localize(dt.datetime.utcnow()).astimezone(india).strftime(fmt))
print(all_timezones)
print(india.localize(dt.datetime.now()).strftime(fmt))
print('--' * 4)
df1['time'] = timezone('Asia/Calcutta').localize(dt.datetime.now()).strftime(fmt)
df1.to_excel('dem1.xlsx', index = False)
print('--' * 5)
df1.at[3,'col2'] = 'up'
for i in range(len(df1)):
  df1.at[i,'col1'] = 'up'

df1.to_excel('dem1.xlsx', index = False)

## Rename 'popu' column to 'population' >>>dfnew = df.rename(columns={'popu': 'population'})
## Add a list as a new column >>>dfnew['capital city'] = ['Rome','Madrid','Athens','Paris','Lisbon']
## Add an array as a new column  >>>dfnew['Calling code'] = np.array([39,34,30,33,351])
# Delete using del >>>del dfnew['Internet domain']
# Delete using drop() >>>dfdrop = dfnew.drop(['Calling code'], axis=1)
#Replace column contents >>>df.percent = 0.001*df.popu   # Data in 'percent' and 'popu' columns are autonatically aligned
"""
Rearrange
# Get the DataFrame column names as a list
clist = list(dfnew.columns)

# Rearrange list the way you like 
clist_new = clist[-1:]+clist[:-1]   # brings the last column in the first place

# Pass the new list to the DataFrame - like a key list in a dict 
dfnew = dfnew[clist_new]

or
clist = ['country','capital city','Internet domains','population','percent','Calling code']
dfnew = dfnew[clist]
"""

df1.to_csv('dem1.xlsx', index = False, sep='\t')
#df1.loc[df1['Name'].str.contains('Mega')] # string filter
#df1.loc[~df1['Name'].str.contains('Mega')] # string filter, not contain
new_df = df1.loc[(df1['col1']== 'r112') & (df1['col2']== 'r112')]# multi col filter
new_df.reset_index(drop=True, inplace=True)#reset index of filtered df
