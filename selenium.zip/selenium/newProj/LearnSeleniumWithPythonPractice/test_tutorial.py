import time
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

# driver = webdriver.Chrome(ChromeDriverManager().install())
driver = webdriver.Firefox(GeckoDriverManager().install())  #made changes in lib file to ignore writting 'Executable Path='
# #[C:\Users\Neeraj\.wdm\drivers\chromedriver\win32\94.0.4606.61]
# #[C:\Users\Neeraj\.wdm\drivers\geckodriver\win64\v0.30.0]
# #[C:\Users\Neeraj\.wdm\drivers\geckodriver\win64\v0.30.0]

driver.get('https://google.com')
